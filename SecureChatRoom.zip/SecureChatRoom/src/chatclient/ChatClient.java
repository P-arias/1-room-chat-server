/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatclient;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.concurrent.atomic.AtomicReference;
import java.math.BigInteger;

public class ChatClient{

    private static String addr = "10.8.72.21";        //IP adress unique to computer where server is running
    private static int port = 8080;
    private static String username = "PedroTest";

    private static String sessionKey;                 //Uniques session key

    private static final String SECRET_KEY = "SECRET_KEY_1234"; //Shared Symmetric key
    private static final String SALT = "123456789";
    private static AtomicReference<PrintWriter> currentWriter = new AtomicReference<>(null);


    public static void main(String[] args) throws Exception {

        //Handles keyboard input
        Thread keyboardHandler = new Thread(ChatClient::handleKeyboardInput);
        keyboardHandler.start();
        while (true) {
            //Send a request to connect to server
            try (Socket socket = new Socket(addr, port)){

                        PrintWriter writer = new PrintWriter(socket.getOutputStream());

                        currentWriter.set(writer);
                        BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                        String line;

                        if(!isSafe(reader))
                        {
                            socket.close();
                            println("NOT CONNECTED!");
                        }else{
                            println("CONNECTED!");
                            writer.println(username);
                            writer.flush();
                        }

                        //Listen for incomming messages
                        while ((line = reader.readLine()) != null && !socket.isClosed()) {
                            receiveMsg(line);
                        }

            } catch (Exception ex) {
                ex.printStackTrace();
                Thread.sleep(1_000);
            }
        }
    }

    private static boolean isSafe(BufferedReader reader) throws IOException{

        BigInteger P = new BigInteger("ffffffffffffffffc90fdaa22168c234c4c6628b80dc1cd129024" +
                "e088a67cc74020bbea63b139b22514a08798e3404ddef9519b3cd" +
                "3a431b302b0a6df25f14374fe1356d6d51c245e485b576625e7ec" +
                "6f44c42e9a637ed6b0bffb984fc1a7f9b", 16);

        BigInteger G = BigInteger.valueOf(2);
        int KEY_LENGTH = 2048;
        SecureRandom SECURE_RANDOM = new SecureRandom();

        BigInteger alicePrivateKey = new BigInteger(KEY_LENGTH, SECURE_RANDOM);
        BigInteger alicePublicKey = G.modPow(alicePrivateKey, P);

        // Send Message 1:
        double Ra = new SecureRandom().nextDouble(1_000_000_000);
        String cipherMessage_1 = G.toString() + "," + alicePublicKey.toString() + "," + P.toString();
        cipherMessage_1 = encrypt(cipherMessage_1, SECRET_KEY);

        String message_1 = Double.toString(Ra) + "," + cipherMessage_1;

        sendMsg(message_1);

        //Receive Message 2 steps:
        // Step 1:

        String[] serverMessages = reader.readLine().split(",");
        double Rb = Double.parseDouble(serverMessages[0]);
        String cipherText = serverMessages[1];
        String plaintext = decrypt(cipherText, SECRET_KEY);
        String[] serverRa_termForKey= plaintext.split(",");
        double serverRa = Double.parseDouble(serverRa_termForKey[0]);
        BigInteger bobPublicKey = new BigInteger(serverRa_termForKey[1]);

        //Authenticate server
        if(Ra != serverRa)
            return false; //failed to authenticate

        //Compute session key
        BigInteger key = bobPublicKey.modPow(alicePrivateKey, P);
        sessionKey = key.toString();
        System.out.println(sessionKey);
        //Message 3

        String cipherTextMessage_3 = Double.toString(Ra) + "," + Double.toString(Rb);
        cipherTextMessage_3 = encrypt(cipherTextMessage_3, SECRET_KEY);
        sendMsg(cipherTextMessage_3);

        return true;
    }
    private static String encrypt(String strToEncrypt, String key) {
        try {
            byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
            IvParameterSpec ivspec = new IvParameterSpec(iv);

            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(key.toCharArray(), SALT.getBytes(), 65536, 256);
            SecretKey tmp = factory.generateSecret(spec);
            SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
            return Base64.getEncoder()
                    .encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            System.out.println("Error while encrypting: " + e.toString());
        }
        return null;
    }
    private static String decrypt(String strToDecrypt, String key) {
        try {
            byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
            IvParameterSpec ivspec = new IvParameterSpec(iv);

            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(key.toCharArray(), SALT.getBytes(), 65536, 256);
            SecretKey tmp = factory.generateSecret(spec);
            SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
        } catch (Exception e) {
            System.out.println("Error while decrypting: " + e.toString());
        }
        return null;
    }

    //Decrypts and print incomming message
    private static void receiveMsg(String line) {
        System.out.println("Encrypted message: " + line);
        System.out.println(decrypt(line, sessionKey));
    }

    private static void sendMsg(String line) {
        try {
            while (true) {
                try {
                    PrintWriter writer = currentWriter.get();
                    writer.println(line);
                    writer.flush();
                    break;
                } catch (Exception ex) {
                    Thread.sleep(500);
                }
            }
        } catch (InterruptedException ex) {
            //This should never happen.
            ex.printStackTrace();
        }
    }

    //Encrypts and send message to server
    private static void handleKeyboardInput() {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String line;
        while (true) {
            try {
                while ((line = reader.readLine()) != null) {
                    String cipher = encrypt(line, sessionKey);
                    System.out.println("Cipher sent to server: " + cipher);
                    sendMsg(cipher);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    private static void println(Object o) {
        System.err.println(o);
    }

}