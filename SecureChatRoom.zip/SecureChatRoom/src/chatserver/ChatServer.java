/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatserver;

/**
 *
 * @author paria
 */

import java.net.*;
import java.io.*;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import javax.crypto.spec.IvParameterSpec;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;

import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.math.BigInteger;

/*Upon receiving a request the server opens a thread and instantiates the ClientHandler class
This class creates a Client and PrintWriter object. The PrintWriter object is assigned the client socket
and this writer is assigned to the Client.
* */

//Holds the writer connected to the socket of this client
class Client{

    private final PrintWriter wr;
    private String sessionKey;      //Unique to this client, established using DHS with PFS
    public Client( PrintWriter wr){

        this.wr = wr;
    }
    public PrintWriter getPrintWriter(){return wr;}

    public void setSessionKey(String sessionKey) {
        this.sessionKey = sessionKey;
    }
    public String getSessionKey(){
        return this.sessionKey;
    }
}




public class ChatServer {

    /**
     * @param args the command line arguments
     *
     */
    //Server holds a queue of all connected clients
static BlockingQueue<Client> clients = new LinkedBlockingQueue<>();

//Handles incoming request
static class ClientHandler implements Runnable {

    Socket s;
    private static final String SECRET_KEY = "SECRET_KEY_1234";  //Shared symmetric key
    private static final String SALT = "123456789";             //Salt


    public ClientHandler(Socket socket) {
        s = socket;
    }

    public void run() {

        try{

            PrintWriter writer = new PrintWriter(s.getOutputStream(), true); //Connects this socket to a PrintWriter object
            Client client = new Client(writer);          //Client is assigned a writer
            clients.add(client);      //Adds client to queue of clients

            BufferedReader reader = new BufferedReader(new InputStreamReader(s.getInputStream()));
            String userName = "";
            if(!isSafe(writer, reader, client)){
                s.close();
                clients.remove(client);
                reader.close();
                writer.close();
            }else {
                userName = reader.readLine();
                System.out.println(userName + " connected.");
                System.out.println(userName + " - key: " + client.getSessionKey());
                broadcastMsg(userName, " connected.", writer);
            }

            //Listens for client messages and broadcast this message to all connected clients
            String line;
            while(!s.isClosed()){
                try{

                    line = reader.readLine();
                    if (line != null){
                        System.out.println("Client: " + userName + " --- Cipher: " + line);
                        line = decrypt(line, client.getSessionKey()); //decrypts the message with the sender's session key before broadcasting
                        System.out.println("Client: " + userName + " --- Plaintext: " + line);
                        broadcastMsg(userName, line, writer);
                    }



                }
                catch(SocketException ex){
                    s.close();
                    broadcastMsg(userName, " disconnected.", writer);
                    clients.remove(client);
                    reader.close();
                    writer.close();
                }

            }

        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }
    //Authenticate this client and establishes a session key for this client
    private static boolean isSafe(PrintWriter writer, BufferedReader reader, Client client) throws IOException{

        //Message 1 steps
        // Step 1:
        String[] clientMessage = reader.readLine().split(",");
        int KEY_LENGTH = 2048;
        SecureRandom SECURE_RANDOM = new SecureRandom();

        // Step 2: Server receives client message
        double Ra = Double.parseDouble(clientMessage[0]);
        String cipherText = clientMessage[1];
        String plaintext = decrypt(cipherText, SECRET_KEY);
        String[] termsForNewKey = plaintext.split(",");
        BigInteger G = new BigInteger(termsForNewKey[0]);
        BigInteger alicePublicKey = new BigInteger(termsForNewKey[1]);
        BigInteger P = new BigInteger(termsForNewKey[2]);

        //Message 2
        double Rb = new SecureRandom().nextDouble(1_000_000_000);
        BigInteger bobPrivateKey = new BigInteger(KEY_LENGTH, SECURE_RANDOM);
        BigInteger bobPublicKey = G.modPow(bobPrivateKey, P);

        BigInteger sessionKey = alicePublicKey.modPow(bobPrivateKey, P);
        //System.out.println(sessionKey.toString());////////////////////////////////////////////////////////////////////////////////////
        client.setSessionKey(sessionKey.toString());
        String cipherForClient = Double.toString(Ra) + "," + bobPublicKey.toString();
        cipherForClient = encrypt(cipherForClient, SECRET_KEY);
        String message_2_Responce = Double.toString(Rb) + "," + cipherForClient;

        writer.println(message_2_Responce);
        writer.flush();

        //Message 3
        //Server Authenticates client
        String clientCipherMessage_3 = reader.readLine();
        String clientPlainText = decrypt(clientCipherMessage_3, SECRET_KEY);
        String[] clientMessagesPlain = clientPlainText.split(",");
        Double clientResponce_Rb = Double.parseDouble(clientMessagesPlain[1]);

        if(clientResponce_Rb == Rb){
            return true;
        }
        else{
            return false;
        }

    }

    //Broadcast this message to all connected clients except the sender
    //encrypt the message for each receiver with their own session key
    private void broadcastMsg(String userName, String line, PrintWriter wr) {

        PrintWriter writer;
        for(Client listener: clients){
            synchronized(listener){
                writer = listener.getPrintWriter();
                String cipher = encrypt(userName + ": " + line, listener.getSessionKey());
                if(writer != wr)
                    writer.println(cipher);
                writer.flush();
            }
        }

    }

    private static String encrypt(String strToEncrypt, String key) {
        try {
            byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
            IvParameterSpec ivspec = new IvParameterSpec(iv);

            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(key.toCharArray(), SALT.getBytes(), 65536, 256);
            SecretKey tmp = factory.generateSecret(spec);
            SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivspec);
            return Base64.getEncoder()
                    .encodeToString(cipher.doFinal(strToEncrypt.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            System.out.println("Error while encrypting: " + e.toString());
        }
        return null;
    }
    private static String decrypt(String strToDecrypt, String key) {
        try {
            byte[] iv = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
            IvParameterSpec ivspec = new IvParameterSpec(iv);

            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            KeySpec spec = new PBEKeySpec(key.toCharArray(), SALT.getBytes(), 65536, 256);
            SecretKey tmp = factory.generateSecret(spec);
            SecretKeySpec secretKey = new SecretKeySpec(tmp.getEncoded(), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, secretKey, ivspec);
            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
        } catch (Exception e) {
            System.out.println("Error while decrypting: " + e.toString());
        }
        return null;
    }

}


    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        ServerSocket ss = new ServerSocket(8080);
        while(true){
            Socket s = ss.accept();
            ClientHandler handler = new ClientHandler(s);
            Thread worker = new Thread(handler);
            worker.start();
        }
    }

}